#!/bin/bash

directories=(
    "/var/containers/Bundle/Application/.jbroot-08056B3062D10DE8/tmp"
    "/var/containers/Data/System/D9221314-A599-4B02-8928-01D90BCB7C22/Library/Caches/com.apple.PaperBoardUI"
    "/var/mobile/Containers/Shared/AppGroup/.jbroot-08056B3062D10DE8/var/mobile/RootHidePatcher"
    "/var/mobile/Containers/Shared/AppGroup/.jbroot-08056B3062D10DE8/var/mobile/Library/Application Support/Containers/com.roothide.patcher/Documents/Inbox"
    "/var/containers/Bundle/Application/.jbroot-08056B3062D10DE8/var/mobile/Library/Filza/.Trash"
    "/var/mobile/Containers/Shared/AppGroup/.jbroot-08056B3062D10DE8/var/mobile/RootHidePatcher/.Inbox"
)

for dir in "${directories[@]}"; do
    if [ -d "$dir" ]; then
        rm -rf "$dir"/*
        echo "已清理目录: $dir"
    else
        echo "目录 $dir 不存在"
    fi
done