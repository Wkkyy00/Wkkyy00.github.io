#!/bin/bash

for file in *.deb; do
    # 使用正则表达式去除末尾的括号数字或短横线数字
    newname=$(echo "$file" | sed -E 's/(.*)(\([0-9]+\)|-[0-9]+)\.deb$/\1.deb/')
    # 仅当新文件名不同时才重命名
    if [[ "$file" != "$newname" ]]; then
        mv -v "$file" "$newname"
    fi
done