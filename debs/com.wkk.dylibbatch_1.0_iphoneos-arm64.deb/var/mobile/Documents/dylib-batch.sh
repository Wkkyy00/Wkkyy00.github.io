#!/bin/bash

# deb文件dylib提取工具
# 功能：自动识别并提取deb包中的.dylib文件，按deb文件名创建对应目录存放
readonly SCRIPT_NAME="${0##*/}"

# 颜色输出配置
RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
NC='\033[0m'  # 重置颜色

# 常见的dylib文件存放路径（按优先级排序）
DYLIB_PATHS=(
    "Library/MobileSubstrate/DynamicLibraries"
    "var/jb/Library/MobileSubstrate/DynamicLibraries"
)

# 检查必要依赖工具
check_dependencies() {
    local dependencies=("dpkg-deb" "file" "mkdir" "cp" "rm" "find" "ls")
    for dep in "${dependencies[@]}"; do
        if ! command -v "$dep" >/dev/null 2>&1; then
            echo -e "${RED}错误：缺少必要依赖工具 - $dep${NC}"
            exit 1
        fi
    done
}

# 验证文件是否为有效的deb包
validate_deb() {
    local file="$1"
    # 检查文件是否存在且为有效的deb包
    if [ ! -f "$file" ]; then
        return 1
    fi
    # 使用file命令验证文件类型
    file -b "$file" | grep -q "Debian binary package"
}

# 从单个deb文件中提取dylib
extract_dylib() {
    local deb_file="$1"
    local base_name="${deb_file%.deb}"  # 去除.deb扩展名作为基础名称
    local temp_dir="${base_name}_temp"  # 临时解压目录
    local output_dir="$base_name"       # 最终输出目录（以deb文件名为名）
    
    # 创建输出目录
    if ! mkdir -p "$output_dir"; then
        echo -e "${RED}失败：无法创建输出目录 $output_dir${NC}"
        return 1
    fi
    
    # 解压deb文件到临时目录
    echo -e "${BLUE}正在解压: $deb_file${NC}"
    if ! mkdir -p "$temp_dir" || ! dpkg-deb -R "$deb_file" "$temp_dir" >/dev/null 2>&1; then
        echo -e "${RED}失败：解压 $deb_file 时出错${NC}"
        rm -rf "$temp_dir" "$output_dir"  # 清理残留文件
        return 1
    fi
    
    # 查找并复制dylib文件
    local found=0
    # 先检查常见路径
    for path in "${DYLIB_PATHS[@]}"; do
        local dylib_full_path="${temp_dir}/${path}"
        if [ -d "$dylib_full_path" ]; then
            # 查找该目录下的.dylib文件
            local dylib_files=$(find "$dylib_full_path" -maxdepth 1 -type f -name "*.dylib")
            if [ -n "$dylib_files" ]; then
                echo -e "${YELLOW}在路径找到dylib: $path${NC}"
                cp -f "$dylib_full_path"/*.dylib "$output_dir/" >/dev/null 2>&1
                found=$((found + 1))
            fi
        fi
    done
    
    # 如果常见路径未找到，尝试全局搜索整个解压目录
    if [ $found -eq 0 ]; then
        echo -e "${YELLOW}常见路径未找到dylib，尝试全局搜索...${NC}"
        local dylib_files=$(find "$temp_dir" -type f -name "*.dylib")
        if [ -n "$dylib_files" ]; then
            echo -e "${YELLOW}全局搜索找到dylib文件${NC}"
            cp -f $dylib_files "$output_dir/" >/dev/null 2>&1
            found=1
        fi
    fi
    
    # 清理临时解压目录
    rm -rf "$temp_dir"
    
    # 检查提取结果
    if [ $found -gt 0 ]; then
        local count=$(ls -1 "$output_dir"/*.dylib 2>/dev/null | wc -l)
        echo -e "${GREEN}成功：已提取 $count 个dylib文件到 $output_dir${NC}"
        return 0
    else
        echo -e "${RED}失败：在 $deb_file 中未找到任何.dylib文件${NC}"
        rm -rf "$output_dir"  # 清理空目录
        return 1
    fi
}

# 主函数
main() {
    # 检查依赖工具
    check_dependencies

    # 获取当前目录下所有.deb文件
    local deb_files=(*.deb)
    local valid_debs=()
    
    # 筛选有效的deb文件
    for file in "${deb_files[@]}"; do
        if validate_deb "$file"; then
            valid_debs+=("$file")
        fi
    done
    
    # 检查是否有有效deb文件
    if [ ${#valid_debs[@]} -eq 0 ]; then
        echo -e "${YELLOW}未发现有效的.deb文件，请将脚本放在包含deb文件的目录中运行${NC}"
        exit 1
    fi
    
    # 显示找到的deb文件数量
    echo -e "${YELLOW}检测到 ${#valid_debs[@]} 个有效deb文件，开始提取dylib...${NC}\n"
    
    # 处理每个有效deb文件
    local success=0
    local fail=0
    
    for deb in "${valid_debs[@]}"; do
        echo -e "=== 正在处理: $deb ==="
        if extract_dylib "$deb"; then
            ((success++))
        else
            ((fail++))
        fi
        echo ""  # 增加空行分隔
    done
    
    # 显示最终统计结果
    echo -e "${GREEN}提取完成 | 成功: ${success} | 失败: ${fail}${NC}"
    echo -e "${BLUE}所有提取的dylib文件已按deb文件名保存在对应目录中${NC}"
}

# 启动主函数
main "$@"