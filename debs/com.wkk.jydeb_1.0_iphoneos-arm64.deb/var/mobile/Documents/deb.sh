#!/bin/bash
ROOTLESS_PREFIX="/var/jb"
TMP_DIR=".deb_temp"

cleanup() { rm -rf "$TMP_DIR"; }
trap cleanup EXIT

mkdir -p "$TMP_DIR" || exit 1

for deb in *.deb; do
    [ -f "$deb" ] || continue
    echo "深度解压: $deb"
    
    BASE_NAME="${deb%.deb}"
    OUTPUT_DIR="./${BASE_NAME}"
    
    if [ -d "$OUTPUT_DIR" ]; then
        echo "⚠️ 目录已存在: $OUTPUT_DIR, 跳过处理"
        continue
    fi

    # 强制使用完整解包模式
    ( cd "$TMP_DIR" && $ROOTLESS_PREFIX/usr/bin/ar -xv ../"$deb" ) || continue
    
    mkdir -p "$OUTPUT_DIR"
    
    # 增强型控制文件处理
    control_found=0
    for control_file in "$TMP_DIR"/control.tar.* "$TMP_DIR"/control.tar; do
        if [ -f "$control_file" ]; then
            [ $control_found -eq 0 ] && mkdir -p "$OUTPUT_DIR/DEBIAN"
            case "$control_file" in
                *.gz)   tar -xzf "$control_file" -C "$OUTPUT_DIR/DEBIAN" ;;
                *.bz2)  tar -xjf "$control_file" -C "$OUTPUT_DIR/DEBIAN" ;;
                *.xz)   tar -xJf "$control_file" -C "$OUTPUT_DIR/DEBIAN" ;;
                *.zst)  zstd -dc "$control_file" | tar -x -C "$OUTPUT_DIR/DEBIAN" ;;
                *)      tar -xf "$control_file" -C "$OUTPUT_DIR/DEBIAN" ;;
            esac
            control_found=1
        fi
    done
    [ $control_found -eq 1 ] && echo "✅ DEBIAN目录提取完成"
    
    # 增强型数据文件处理（支持所有已知压缩格式）
    data_found=0
    for data_file in "$TMP_DIR"/data.tar.* "$TMP_DIR"/data.tar; do
        if [ -f "$data_file" ]; then
            case "$data_file" in
                *.gz)   tar -xzf "$data_file" -C "$OUTPUT_DIR" ;;
                *.bz2)  tar -xjf "$data_file" -C "$OUTPUT_DIR" ;;
                *.xz)   tar -xJf "$data_file" -C "$OUTPUT_DIR" ;;
                *.lzma) tar --lzma -xf "$data_file" -C "$OUTPUT_DIR" ;;
                *.zst)  zstd -dc "$data_file" | tar -x -C "$OUTPUT_DIR" ;;
                *)      tar -xf "$data_file" -C "$OUTPUT_DIR" ;;
            esac
            data_found=1
        fi
    done
    [ $data_found -eq 1 ] && echo "✅ 系统文件提取完成" || echo "⚠️ 警告：未找到数据文件"
    
    # 权限修复（兼容无数据文件情况）
    if [ -d "$OUTPUT_DIR" ]; then
        find "$OUTPUT_DIR" -type d -exec chmod 0755 {} +
        find "$OUTPUT_DIR" -type f -exec chmod 0644 {} +
    fi
    
    echo "🎉 解压完成：$OUTPUT_DIR"
    rm -rf "$TMP_DIR"/*
done