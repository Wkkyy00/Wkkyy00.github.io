#!/bin/bash
ROOTLESS_PREFIX="/var/jb"
TMP_DIR=".deb_temp"

cleanup() { rm -rf "$TMP_DIR"; }
trap cleanup EXIT

mkdir -p "$TMP_DIR" || exit 1

for deb in *.deb; do
    [ -f "$deb" ] || continue
    echo "深度解压: $deb"
    
    # 新核心逻辑：直接使用原始文件名
    BASE_NAME="${deb%.deb}"
    OUTPUT_DIR="./${BASE_NAME}"
    
    # 防覆盖检测
    if [ -d "$OUTPUT_DIR" ]; then
        echo "⚠️ 目录已存在: $OUTPUT_DIR, 跳过处理"
        continue
    fi

    # 第一阶段：提取ar包内容
    ( cd "$TMP_DIR" && $ROOTLESS_PREFIX/usr/bin/ar -x ../"$deb" ) || continue
    
    mkdir -p "$OUTPUT_DIR"
    
    # 第二阶段：处理控制文件
    if ls "$TMP_DIR"/control.tar.* 1>/dev/null 2>&1; then
        mkdir -p "$OUTPUT_DIR/DEBIAN"
        for control_file in "$TMP_DIR"/control.tar.*; do
            case "$control_file" in
                *.gz)  tar -xzf "$control_file" -C "$OUTPUT_DIR/DEBIAN" ;;
                *.bz2) tar -xjf "$control_file" -C "$OUTPUT_DIR/DEBIAN" ;;
                *.xz)  tar -xJf "$control_file" -C "$OUTPUT_DIR/DEBIAN" ;;
                *.zst) zstd -dc "$control_file" | tar -x -C "$OUTPUT_DIR/DEBIAN" ;;
            esac
        done
        echo "✅ DEBIAN目录提取完成"
    fi
    
    # 第三阶段：处理数据文件
    if ls "$TMP_DIR"/data.tar.* 1>/dev/null 2>&1; then
        for data_file in "$TMP_DIR"/data.tar.*; do
            case "$data_file" in
                *.gz)  tar -xzf "$data_file" -C "$OUTPUT_DIR" ;;
                *.bz2) tar -xjf "$data_file" -C "$OUTPUT_DIR" ;;
                *.xz)  tar -xJf "$data_file" -C "$OUTPUT_DIR" ;;
                *.zst) zstd -dc "$data_file" | tar -x -C "$OUTPUT_DIR" ;;
            esac
        done
        echo "✅ 系统文件提取完成"
    fi
    
    # 第四阶段：权限修复
    find "$OUTPUT_DIR" -type d -exec chmod 0755 {} +
    find "$OUTPUT_DIR" -type f -exec chmod 0644 {} +
    
    echo "🎉 完整解压到：$OUTPUT_DIR"
    rm -rf "$TMP_DIR"/*
done