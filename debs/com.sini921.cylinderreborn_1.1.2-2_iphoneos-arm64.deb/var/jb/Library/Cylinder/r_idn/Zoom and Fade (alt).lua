return function(page, offset, width, height)
    local percent = offset/width
    page:translate(offset)
    page.alpha = 1 - math.abs(percent)
    
    -- 修改：无论左右滑动都应用缩小效果
    local scale = 1 - math.abs(percent)  -- 使用绝对值确保总是缩小
    
    page:scale(scale)
end,
0.15  -- 保持快速缩回