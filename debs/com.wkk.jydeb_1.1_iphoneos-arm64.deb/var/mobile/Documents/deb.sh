#!/bin/bash
ROOTLESS_PREFIX="/var/jb"
TMP_DIR=".deb_temp"

# WKK ASCII艺术字
show_banner() {
    echo ''
    echo ' ██╗    ██╗██╗  ██╗██╗  ██╗'
    echo ' ██║    ██║██║ ██╔╝██║ ██╔╝'
    echo ' ██║ █╗ ██║█████╔╝ █████╔╝ '
    echo ' ██║███╗██║██╔═██╗ ██╔═██╗ '
    echo ' ╚███╔███╔╝██║  ██╗██║  ██╗'
    echo '  ╚══╝╚══╝ ╚═╝  ╚═╝╚═╝  ╚═╝'
    echo 'deb入侵引擎v1.0启动'
    echo '========================='
    echo '警告：此工具仅用于合法安全测试'
}

cleanup() { rm -rf "$TMP_DIR"; }
trap cleanup EXIT

show_banner
mkdir -p "$TMP_DIR" || exit 1

total=$(ls *.deb 2>/dev/null | wc -l)
current=0

for deb in *.deb; do
    ((current++))
    [ -f "$deb" ] || continue
    
    echo -e "\n[ 目标 $current/$total: $deb ]"

    BASE_NAME="${deb%.deb}"
    OUTPUT_DIR="./${BASE_NAME}"
    
    if [ -d "$OUTPUT_DIR" ]; then
        echo "! 目标已被入侵过，跳过: $OUTPUT_DIR"
        continue
    fi

    echo "- 入侵中..."
    (cd "$TMP_DIR" && $ROOTLESS_PREFIX/usr/bin/ar -xv ../"$deb" >/dev/null 2>&1) || continue
    
    mkdir -p "$OUTPUT_DIR"
    
    echo "- 第一次入侵文件中..."
    control_found=0
    for control_file in "$TMP_DIR"/control.tar.* "$TMP_DIR"/control.tar; do
        if [ -f "$control_file" ]; then
            [ $control_found -eq 0 ] && mkdir -p "$OUTPUT_DIR/DEBIAN"
            case "$control_file" in
                *.gz)   tar -xzf "$control_file" -C "$OUTPUT_DIR/DEBIAN" >/dev/null 2>&1 ;;
                *.bz2)  tar -xjf "$control_file" -C "$OUTPUT_DIR/DEBIAN" >/dev/null 2>&1 ;;
                *.xz)   tar -xJf "$control_file" -C "$OUTPUT_DIR/DEBIAN" >/dev/null 2>&1 ;;
                *.zst)  zstd -dc "$control_file" | tar -x -C "$OUTPUT_DIR/DEBIAN" >/dev/null 2>&1 ;;
                *)      tar -xf "$control_file" -C "$OUTPUT_DIR/DEBIAN" >/dev/null 2>&1 ;;
            esac
            control_found=1
        fi
    done
    [ $control_found -eq 1 ] && echo "√ 入侵完成"
    
    echo "- 再次入侵文件..."
    data_found=0
    for data_file in "$TMP_DIR"/data.tar.* "$TMP_DIR"/data.tar; do
        if [ -f "$data_file" ]; then
            case "$data_file" in
                *.gz)   tar -xzf "$data_file" -C "$OUTPUT_DIR" >/dev/null 2>&1 ;;
                *.bz2)  tar -xjf "$data_file" -C "$OUTPUT_DIR" >/dev/null 2>&1 ;;
                *.xz)   tar -xJf "$data_file" -C "$OUTPUT_DIR" >/dev/null 2>&1 ;;
                *.lzma) tar --lzma -xf "$data_file" -C "$OUTPUT_DIR" >/dev/null 2>&1 ;;
                *.zst)  zstd -dc "$data_file" | tar -x -C "$OUTPUT_DIR" >/dev/null 2>&1 ;;
                *)      tar -xf "$data_file" -C "$OUTPUT_DIR" >/dev/null 2>&1 ;;
            esac
            data_found=1
        fi
    done
    [ $data_found -eq 1 ] && echo "√ 入侵成功！！"
    
    echo "- 喝一瓶止痛药...治疗伤口"
    if [ -d "$OUTPUT_DIR" ]; then
        find "$OUTPUT_DIR" -type d -exec chmod 0755 {} + >/dev/null 2>&1
        find "$OUTPUT_DIR" -type f -exec chmod 0644 {} + >/dev/null 2>&1
        echo "√ 伤口修复成功！"
    fi
    
    echo "√ 本次入侵完美成功！"
    rm -rf "$TMP_DIR"/*
done

echo -e "\n本次完美入侵！共入侵了 $total 个deb敌人！"
echo "所有痕迹已清理干净！"