#!/bin/bash

# 检查logo.png是否存在
if [ -f "logo.png" ]; then
    # 定义要重命名为的文件名数组
    names=(
        "apple-logo-black-d3x@3x~iphone.png"
        "apple-logo-black-d5x@3x~iphone.png"
        "apple-logo-black-n84@2x~iphone.png"
        "apple-logo-black@2x~iphone.png"
        "apple-logo-black@3x~iphone.png"
        "apple-logo-d3x@3x~iphone.png"
        "apple-logo-d5x@3x~iphone.png"
        "apple-logo-n84@2x~iphone.png"
        "apple-logo@2x~iphone.png"
        "apple-logo@3x~iphone.png"
    )

    # 循环重命名
    for name in "${names[@]}"; do
        cp "logo.png" "$name"
    done
else
    echo "logo.png 文件不存在"
fi