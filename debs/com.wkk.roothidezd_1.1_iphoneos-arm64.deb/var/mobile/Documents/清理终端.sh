#!/bin/bash

# 获取当前脚本的绝对路径
script_path=$(realpath "$0")

# 提取 .jbroot- 后的随机字符串（基于脚本路径）
jbroot_id=$(echo "$script_path" | sed -n 's/.*\.jbroot-\([^/]*\).*/\1/p')

if [ -z "$jbroot_id" ]; then
    echo "错误：无法确定 jbroot 标识符。请确保脚本路径正确。"
    exit 1
fi

directories=(
    "/var/containers/Bundle/Application/.jbroot-${jbroot_id}/tmp"
    "/var/containers/Data/System/D9221314-A599-4B02-8928-01D90BCB7C22/Library/Caches/com.apple.PaperBoardUI"
    "/var/mobile/Containers/Shared/AppGroup/.jbroot-${jbroot_id}/var/mobile/RootHidePatcher"
    "/var/mobile/Containers/Shared/AppGroup/.jbroot-${jbroot_id}/var/mobile/Library/Application Support/Containers/com.roothide.patcher/Documents/Inbox"
    "/var/containers/Bundle/Application/.jbroot-${jbroot_id}/var/mobile/Library/Filza/.Trash"
    "/var/mobile/Containers/Shared/AppGroup/.jbroot-${jbroot_id}/var/mobile/RootHidePatcher/.Inbox"
)

for dir in "${directories[@]}"; do
    if [ -d "$dir" ]; then
        rm -rf "$dir"/*
        echo "已清理目录: $dir"
    else
        echo "目录不存在，跳过: $dir"
    fi
done