#!/bin/bash

# 自动识别版Deb处理脚本
readonly SCRIPT_NAME="${0##*/}"

# 颜色输出
RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
NC='\033[0m'

check_dependencies() {
    command -v dpkg-deb >/dev/null || {
        echo -e "${RED}错误：缺少必要依赖 - dpkg-deb${NC}"
        exit 1
    }
}

validate_deb() {
    file -b "$1" | grep -q "Debian binary package"
}

validate_package_dir() {
    [ -d "$1/DEBIAN" ] && [ -f "$1/DEBIAN/control" ]
}

auto_extract() {
    local deb_files=(*.deb)
    local success=0 fail=0

    for file in "${deb_files[@]}"; do
        if validate_deb "$file"; then
            local base="${file%.deb}"
            local output="${base}"
            
            echo -e "${BLUE}解压中: ${file}${NC}"
            if mkdir -p "$output" && dpkg-deb -R "$file" "$output"; then
                echo -e "${GREEN}成功 → ${output}/${NC}"
                ((success++))
            else
                echo -e "${RED}失败: ${file}${NC}"
                rm -rf "$output"
                ((fail++))
            fi
        else
            echo -e "${YELLOW}跳过无效文件: ${file}${NC}"
            ((fail++))
        fi
    done

    echo -e "\n${GREEN}解压完成 | 成功: ${success} | 失败: ${fail}${NC}"
}

auto_package() {
    local dirs=()
    local success=0 fail=0

    for dir in */; do
        if validate_package_dir "$dir"; then
            dirs+=("$dir")
        fi
    done

    for dir in "${dirs[@]}"; do
        local control_file="${dir}DEBIAN/control"
        local pkg_name=$(awk -F': ' '/^Package:/ {print $2}' "$control_file")
        local version=$(awk -F': ' '/^Version:/ {print $2}' "$control_file")
        local arch=$(awk -F': ' '/^Architecture:/ {print $2}' "$control_file")
        local output="${pkg_name}_${version}_${arch}.deb"

        echo -e "${BLUE}打包中: ${dir}${NC}"
        if dpkg-deb -b "$dir" "$output" >/dev/null; then
            echo -e "${GREEN}生成 → ${output}${NC}"
            ((success++))
        else
            echo -e "${RED}失败: ${dir}${NC}"
            ((fail++))
        fi
    done

    echo -e "\n${GREEN}打包完成 | 成功: ${success} | 失败: ${fail}${NC}"
}

main() {
    check_dependencies

    local deb_count=$(ls *.deb 2>/dev/null | wc -l)
    local package_dirs=0

    for dir in */; do
        validate_package_dir "$dir" && ((package_dirs++))
    done

    if [ $deb_count -gt 0 ]; then
        echo -e "${YELLOW}检测到 ${deb_count} 个deb文件，开始自动解压...${NC}"
        auto_extract
    elif [ $package_dirs -gt 0 ]; then
        echo -e "${YELLOW}检测到 ${package_dirs} 个打包目录，开始自动构建...${NC}"
        auto_package
    else
        echo -e "${YELLOW}当前目录未发现可处理的deb文件或打包目录${NC}"
        echo -e "有效结构："
        echo -e "  • *.deb 文件"
        echo -e "  • 包含DEBIAN/control的目录"
        exit 1
    fi
}

main "$@"