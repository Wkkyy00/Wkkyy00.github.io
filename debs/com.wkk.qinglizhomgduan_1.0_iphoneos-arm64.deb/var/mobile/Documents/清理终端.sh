#!/bin/bash

directories=(
    "/var/containers/Bundle/Application/.jbroot-2C78BD5008A21102/tmp（这是无根插件缓目录，rh用户在转换插件前无根插件存放处，可以自行查看，换自己路径时覆盖""内所有路径与文字且保留""，下方同理）"
    "/var/containers/Data/System/D9221314-A599-4B02-8928-01D90BCB7C22/Library/Caches/com.apple.PaperBoardUI（注销缓存目录）"
    "/var/mobile/Containers/Shared/AppGroup/.jbroot-2C78BD5008A21102/var/mobile/RootHidePatcher（无根转隐根插件目录）"
    "/var/mobile/Containers/Shared/AppGroup/.jbroot-2C78BD5008A21102/var/mobile/Library/Application Support/Containers/com.roothide.patcher/Documents/Inbox（无根/隐根目录）"
    "/var/containers/Bundle/Application/.jbroot-2C78BD5008A21102/var/mobile/Library/Filza/.Trash（回收站，可自行抉择是否填入）"
)

for dir in "${directories[@]}"; do
    if [ -d "$dir" ]; then
        rm -rf "$dir"/*
        echo "已清理目录: $dir"
    else
        echo "目录 $dir 不存在"
    fi
done