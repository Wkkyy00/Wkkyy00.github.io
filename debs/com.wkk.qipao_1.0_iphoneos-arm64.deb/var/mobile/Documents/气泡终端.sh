#!/bin/bash

# 处理我方气泡文件
if [ -f 我方气泡.png ]; then
    our_new_names=(
        "ChatRoom_Bubble_Voice_Receiver_Recording_HL@3x.png"
        "ChatRoom_Bubble_Voice_Receiver_Recording@3x.png"
        "ChatRoom_Bubble_Text_Sender_Green_HL@3x.png"
        "ChatRoom_Bubble_App_Sender_Dark@3x.png"
        "ChatRoom_Bubble_Text_Sender_Green@3x.png"
        "ChatRoom_Bubble_App_Sender@3x.png"
        "ChatRoom_Bubble_Text_Sender_Green_Dark@3x.png"
        "ChatRoom_Bubble_Text_Sender_Green_HL_Dark@3x.png"
    )

    for our_new_name in "${our_new_names[@]}"; do
        cp 我方气泡.png "$our_new_name"
        if [ $? -eq 0 ]; then
            echo "Successfully copied and renamed 我方气泡.png to $our_new_name"
        else
            echo "Failed to copy and rename 我方气泡.png to $our_new_name"
        fi
    done

    # 删除我方气泡原始文件
    rm 我方气泡.png
    if [ $? -eq 0 ]; then
        echo "Successfully deleted the original 我方气泡.png"
    else
        echo "Failed to delete the original 我方气泡.png"
    fi
else
    echo "我方气泡.png does not exist in the current directory."
fi

# 处理对方气泡文件
if [ -f 对方气泡.png ]; then
    other_new_names=(
        "ChatRoom_Bubble_Text_Receiver_White@3x.png"
        "ChatRoom_Bubble_Text_Receiver_White_HL@3x.png"
        "ChatRoom_Bubble_Text_Receiver_Dark@3x.png"
        "ChatRoom_Bubble_Text_Receiver_Dark_HL@3x.png"
    )

    for other_new_name in "${other_new_names[@]}"; do
        cp 对方气泡.png "$other_new_name"
        if [ $? -eq 0 ]; then
            echo "Successfully copied and renamed 对方气泡.png to $other_new_name"
        else
            echo "Failed to copy and rename 对方气泡.png to $other_new_name"
        fi
    done

    # 删除对方气泡原始文件
    rm 对方气泡.png
    if [ $? -eq 0 ]; then
        echo "Successfully deleted the original 对方气泡.png"
    else
        echo "Failed to delete the original 对方气泡.png"
    fi
else
    echo "对方气泡.png does not exist in the current directory."
fi

# 处理红包气泡文件
if [ -f 红包气泡.png ]; then
    hongbao_new_names=(
        "ChatRoom_Bubble_HB_Overtime_Dender_Dark@3x.png"
        "ChatRoom_Bubble_HB_Overtime_Receiver@3x.png"
        "ChatRoom_Bubble_HB_Sender_Handled@3x.png"
        "ChatRoom_Bubble_HB_Overtime_Sender@3x.png"
        "ChatRoom_Bubble_HB_Sender_Handled@3x.png"
        
        "ChatRoom_Bubble_HB_Receiver_Handled_Dark@3x.png"
        
        "ChatRoom_Bubble_HB_Overtime_Receiver_Dark@3x.png"
        
        "ChatRoom_Bubble_HB_Sender_Dark@3x.png"
        
        "ChatRoom_Bubble_HB_Sender@3x.png"
        
        "ChatRoom_Bubble_HB_Receiver_Handled@3x.png"
        
        "ChatRoom_Bubble_HB_Receiver_Dark@3x.png"
        
        "ChatRoom_Bubble_HB_Sender_Handled_Dark@3x.png"
        
    )

    for hongbao_new_name in "${hongbao_new_names[@]}"; do
        cp 红包气泡.png "$hongbao_new_name"
        if [ $? -eq 0 ]; then
            echo "Successfully copied and renamed 红包气泡.png to $hongbao_new_name"
        else
            echo "Failed to copy and rename 红包气泡.png to $hongbao_new_name"
        fi
    done

    # 删除红包气泡原始文件
    rm 红包气泡.png
    if [ $? -eq 0 ]; then
        echo "Successfully deleted the original 红包气泡.png"
    else
        echo "Failed to delete the original 红包气泡.png"
    fi
else
    echo "红包气泡.png does not exist in the current directory."
fi