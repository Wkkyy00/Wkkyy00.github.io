#import <Foundation/Foundation.h>

@interface @@CLASSPREFIX@@PCServiceDelegate : NSObject <NSXPCListenerDelegate>
@end
