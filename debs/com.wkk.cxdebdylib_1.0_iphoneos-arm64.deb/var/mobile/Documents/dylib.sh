#!/bin/bash

red="\033[38;5;196m"
blu="\033[38;5;39m"
nco="\033[0m"
exclude_list="/var/jb/usr/local/lib/wkk_list"

filtered_pkgs=$(dpkg --get-selections \
    | grep -v -E 'deinstall|gsc\.|cy\+|swift-|build-|llvm|clang' \
    | grep -vw 'git' \
    | grep -vwFf "$exclude_list" 2>/dev/null \
    | awk '{print $1}')

pkg_count=$(echo "$filtered_pkgs" | wc -w)

echo -e "${blu}已安装的插件数量： ${nco}${pkg_count}"
echo

index=1
for pkg in $filtered_pkgs; do
    pkg_fullname=$([ ! -z "$(dpkg-query -W -f='${Name}' "$pkg")" ] && \
        dpkg-query -W -f='${Name}_${Version}_${Architecture}' "$pkg" || \
        dpkg-query -W -f='${Package}_${Version}_${Architecture}' "$pkg")
    
    echo -e "${blu}${index}: ${nco}${pkg_fullname}"
    index=$((index + 1))
done

echo